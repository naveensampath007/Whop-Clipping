REBUILT VIDEOS 05 AND 06 — V6

These replace the two V5 runway-photo slideshows. Both are 14.8 seconds, 1080×1920, 30 fps, H.264/AAC.

05: six distinct making/product photographs → actual yellow-stone mounting → handheld finished mannequin footage → worn diamond close-up → Kylie on the runway.
06: six different making/product photographs → hands fitting the fringe → rotating finished mannequin → worn close-up → Kylie on the runway.

Split-screen is limited to the changing photographs. The moving making, mannequin and wearer sections fill the frame beneath the required campaign line. All images, video and audio come from the approved library. Each video carries one unchanged approved line. YouTube titles/descriptions are included.
